Extract to a folder.
Start a terminal and go to your selected folder.

Type this line and the game should start.
java -jar Tetris.jar



If you want to play with a friend, change the port in the config.cfg file to the your prefered port number.
